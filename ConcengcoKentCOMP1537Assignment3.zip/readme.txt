Kent Danielle L. Concengco, A01290340, Set 1A, February 5 2022

This assignment is 100% complete.